# AlternateDataStream.ps1

$scriptBlockSetStream = {cmd /C `"echo $($Args[0])`>$($Args[1]):$($Args[2])`"}
$scriptBlockGetStream = {cmd /C `"more `<$($Args[0]):$($Args[1])`"}

$streamName = "HKEY_CURRENT_USER\Software\Policies\Microsoft\Internet Explorer\Main"
$File = ""
$streamContent = Split-Path -Path $File -Parent

# Set the data stream
Invoke-Command -ScriptBlock $scriptBlockSetStream  -ArgumentList $streamContent,$File,$streamName
# Get the Data Stream
$res = Invoke-Command -ScriptBlock $scriptBlockGetStream  -ArgumentList $File,$streamName
$res