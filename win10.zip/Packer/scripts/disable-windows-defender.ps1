$regpath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
if (!(Test-Path $regpath -PathType Container)) {
    New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft" -Name 'Windows Defender' -ItemType Container | Out-Null
}
Set-ItemProperty -Path $regpath -Name "DisableAntiSpyware" -Value 1 -Type DWord
