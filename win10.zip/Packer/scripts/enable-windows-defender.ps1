Set-ItemProperty -Path $regpath -Name "DisableAntiSpyware" -Value 0 -Type DWord
