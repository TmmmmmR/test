
#Restart-Computer -Force
#Start-Sleep 20

#set-executionpolicy -executionpolicy unrestricted -force

#Adding python to the path
$theCurrentPath=(Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name PATH).Path
$theUpdatedPath = $theCurrentPath + ';C:\Python27;C:\Python27\Scripts'
Set-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name PATH -Value $theUpdatedPath
$theCurrentPath=(Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name PATH).Path

#Disabling uac
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force

#Disabling windows defender
$regpath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
if (!(Test-Path $regpath -PathType Container)) {
    New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft" -Name 'Windows Defender' -ItemType Container | Out-Null
}
Set-ItemProperty -Path $regpath -Name "DisableAntiSpyware" -Value 1 -Type DWord












#Installing pyautogui and psutil libraries
pip.exe install pyautogui
pip.exe install psutil

#Python script for automating browser refresh
echo 'import pyautogui
import webbrowser
import time

import pyautogui
import webbrowser
import time
import psutil

while True:

    url = "docs.google.com"
    wb = webbrowser.get("C:\Program Files\Internet Explorer\iexplore.exe")
    wb.open(url, new=2)

    time.sleep(5)
    try:
        while True:
            pyautogui.press("f5")
            x = pyautogui.locateCenterOnScreen("C:/guest/red.png")
            y = pyautogui.locateCenterOnScreen("C:/guest/allow.png")
            z = pyautogui.locateCenterOnScreen("C:/guest/close.png")
            if x :
                pyautogui.click(x[0], x[1])
                pyautogui.press('enter')
            elif y:
                pyautogui.click(y[0], y[1])
            elif z:
                pyautogui.click(z[0], z[1])
            time.sleep(10)
            flag = "iexplore.exe" in (p.name() for p in psutil.process_iter())
            if not flag:
                raise Exception("IExplorer not found")

            print("Refreshing .. ")
    except Exception as e:
        print(e)' > C:\Users\Vagrant\Desktop\browser.py

#Converting the file to utf8
$MyPath = "C:\Users\Vagrant\Desktop\browser.py"
$MyFile = Get-Content $MyPath
$Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
[System.IO.File]::WriteAllLines($MyPath, $MyFile, $Utf8NoBomEncoding)

python C:\Users\Vagrant\Desktop\browser.py
