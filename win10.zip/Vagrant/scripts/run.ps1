#Disabling uac
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force


#Disabling windows defender
$regpath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
if (!(Test-Path $regpath -PathType Container)) {
    New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft" -Name 'Windows Defender' -ItemType Container | Out-Null
}
Set-ItemProperty -Path $regpath -Name "DisableAntiSpyware" -Value 1 -Type DWord


