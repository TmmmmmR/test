# required in order for silent to install to work without popups
certutil -addstore -f "TrustedPublisher" A:\oracle-cert.cer
 
# from http://download.virtualbox.org/virtualbox
$iso_name = 'VBoxGuestAdditions_4.3.14.iso'
$download_url = "http://vagrantboxes.hq.daptiv.com/installs/cookbookresources/$iso_name"
 
(New-Object System.Net.WebClient).DownloadFile($download_url, "c:\windows\temp\$iso_name")
&c:\7-zip\7z.exe x "c:\windows\temp\$iso_name" -oc:\windows\temp\vbox -aoa | Out-Host
&c:\windows\temp\vbox\VBoxWindowsAdditions.exe /S | Out-Host
 